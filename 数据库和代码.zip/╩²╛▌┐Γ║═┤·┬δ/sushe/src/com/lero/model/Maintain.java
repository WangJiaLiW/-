package com.lero.model;

public class Maintain {
	private int  maintainId;
	private String workerNum;
	private String buildName;
	private String date;
	private String detail;
	
	public Maintain(){
		
	}
	public Maintain(String workerNum,String buildName,String date,String detail){
		this.workerNum=workerNum;
		this.buildName=buildName;
		this.date=date;
		this.detail=detail;		
	}
	public int getMaintainId() {
		return maintainId;
	}
	public void setMaintainId(int maintainId) {
		this.maintainId = maintainId;
	}
	public String getWorkerNum() {
		return workerNum;
	}
	public void setWorkerNum(String workerNum) {
		this.workerNum = workerNum;
	}
	public String getBuildName() {
		return buildName;
	}
	public void setBuildName(String buildName) {
		this.buildName = buildName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	

}