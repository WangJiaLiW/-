package com.lero.model;
//�������ݿ⣬����ӳ��
public class Teacher {
	private int teacherId;
	private String teacherNum;
	private String password;
	private String name;
	private String userName;

	public Teacher() {
	}
	public Teacher(String userName, String password) {
		this.teacherNum=userName;
		this.userName=userName;
		this.password = password;
	}
	
	
	public Teacher(String teacherNum,String password,
			String name) {
		this.teacherNum=teacherNum;
		this.userName=teacherNum;
		this.password = password;
		this.name = name;
		
	}
	public int getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}
	public String getTeacherNum() {
		return teacherNum;
	}
	public void setTeacherNum(String teacherNum) {
		this.teacherNum = teacherNum;
		this.userName=teacherNum;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
		this.teacherNum=userName;
	}


}