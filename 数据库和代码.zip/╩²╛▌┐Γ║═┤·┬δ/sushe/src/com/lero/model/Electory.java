package com.lero.model;
//���ݿ�ʵ����
public class Electory {
	private int electoryId;
	private String dormNum;
	private String name;
	private String detail;
	public Electory() {
	}
	public Electory(String dormNum,String name,
			String detail) {
		this.dormNum=dormNum;
		this.name = name;
		this.detail=detail;
		
	}




	

	public int getElectoryId() {
		return electoryId;
	}
	public void setElectoryId(int electoryId) {
		this.electoryId = electoryId;
	}
	public String getDormNum() {
		return dormNum;
	}


	public void setDormNum(String dormNum) {
		this.dormNum = dormNum;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	

	public String getDetail() {
		return detail;
	}


	public void setDetail(String detail) {
		this.detail = detail;
	}
	

}