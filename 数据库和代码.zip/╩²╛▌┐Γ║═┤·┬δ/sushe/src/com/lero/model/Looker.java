package com.lero.model;

public class Looker {
	private int lookerId;
	private String studentNum;
	private String date;
	private String detail;
	private String buildName;
	public  Looker(){
		
		
	}
	
	public Looker(String studentNum,String date,String detail,String buildName){
		this.studentNum=studentNum;
		this.date=date;
		this.detail=detail;
		this.buildName=buildName;
	}

	public int getLookerId() {
		return lookerId;
	}

	public void setLookerId(int lookerId) {
		this.lookerId = lookerId;
	}

	public String getStudentNum() {
		return studentNum;
	}

	public void setStudentNum(String studentNum) {
		this.studentNum = studentNum;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}



	public String getBuildName() {
		return buildName;
	}

	public void setBuildName(String buildName) {
		this.buildName = buildName;
	}
		
		
		
	}