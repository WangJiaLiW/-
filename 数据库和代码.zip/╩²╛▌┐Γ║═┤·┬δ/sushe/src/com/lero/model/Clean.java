package com.lero.model;

public class Clean {
	private String  date;
	private int cleanId;
	private String workerNum;
	private String detail;
	private String buildName; 
	
	public Clean(){
		
	}
	public Clean(String workerNum,String buildName, String detail,String date) {
		this.workerNum = workerNum;
		this.buildName = buildName;
		this.detail = detail;
		this.date=date;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getCleanId() {
		return cleanId;
	}
	public void setCleanId(int cleanId) {
		this.cleanId = cleanId;
	}
	public String getWorkerNum() {
		return workerNum;
	}
	public void setWorkerNum(String workerNum) {
		this.workerNum = workerNum;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getBuildName() {
		return buildName;
	}
	public void setBuildName(String buildName) {
		this.buildName = buildName;
	}


}