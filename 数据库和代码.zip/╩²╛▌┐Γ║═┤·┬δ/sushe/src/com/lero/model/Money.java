package com.lero.model;

public class Money {
	private int moneyId;
	private String name;
	private String amount;
	private String studentNum;
	private String workerNum;
	public Money(){
		
	}
	public Money(String name, String amount,String studentNum,String workerNum) {
		this.name = name;
		this.amount = amount;
		this.studentNum=studentNum;
		this.workerNum=workerNum;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public int getMoneyId() {
		return moneyId;
	}
	public void setMoneyId(int moneyId) {
		this.moneyId = moneyId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStudentNum() {
		return studentNum;
	}
	public void setStudentNum(String studentNum) {
		this.studentNum = studentNum;
	}
	public String getWorkerNum() {
		return workerNum;
	}
	public void setWorkerNum(String workerNum) {
		this.workerNum = workerNum;
	}

}