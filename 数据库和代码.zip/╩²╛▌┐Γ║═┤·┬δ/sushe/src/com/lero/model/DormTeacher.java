package com.lero.model;
//�������ݿ⣬����ӳ��
public class DormTeacher {
	private int dormId;
	private String dormNum;
	private String name;
	private String grade;
	private String date;
	private String electory;
	private String  detail;

	public DormTeacher() {
	}
	
	
	public DormTeacher(String dormNum,String name,String grade,
			String date,String electory,String detail) {
		this.dormNum=dormNum;
		this.name=name;
		this.grade = grade;
		this.date = date;
		this.electory=electory;
		this.detail = detail;
	}


	public int getDormId() {
		return dormId;
	}


	public void setDormId(int dormId) {
		this.dormId = dormId;
	}


	public String getDormNum() {
		return dormNum;
	}


	public void setDormNum(String dormNum) {
		this.dormNum = dormNum;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getElectory() {
		return electory;
	}


	public void setElectory(String electory) {
		this.electory = electory;
	}


	public String getDetail() {
		return detail;
	}


	public void setDetail(String detail) {
		this.detail = detail;
	}

	
}