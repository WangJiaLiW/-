package com.lero.model;
//�������ݿ⣬����ӳ��
public class Worker {
	private int workerId;
	private String workerNum;
	private String userName;
	private String password;
	private String name;
	private String sex;
	private int  tel;

	public Worker() {
	}
	public Worker(String userName, String password) {
		this.workerNum=userName;
		this.userName=userName;
		this.password = password;
	}
	
	
	public Worker(String workerNum,String password,String sex,
			String name,int tel) {
		this.workerNum=workerNum;
		this.userName=workerNum;
		this.password = password;
		this.name = name;
		this.sex=sex;
		this.tel = tel;
	}

	public int getWorkerId() {
		return workerId;
	}

	public void setWorkerId(int workerId) {
		this.workerId = workerId;
	}

	public String getWorkerNum() {
		return workerNum;
	}

	public void setWorkerNum(String workerNum) {
		this.workerNum = workerNum;
		this.userName=workerNum;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getTel() {
		return tel;
	}

	public void setTel(int tel) {
		this.tel = tel;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
		this.workerNum=userName;
	}

}