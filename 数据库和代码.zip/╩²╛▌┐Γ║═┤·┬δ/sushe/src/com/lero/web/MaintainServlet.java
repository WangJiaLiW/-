package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.MaintainDao;
import com.lero.model.Maintain;
import com.lero.model.Worker;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class MaintainServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	MaintainDao maintainDao = new MaintainDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String m_maintainText = request.getParameter("m_maintainText");
		String workerNum=request.getParameter("workerNum");
		String maintainId=request.getParameter("maintainToSelect");
		
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		
		Maintain maintain = new Maintain();
		if("preSave".equals(action)) {
			maintainPreSave(request, response);
			return;
		} else if("save".equals(action)){
			maintainSave(request, response);
			return;
		} else if("delete".equals(action)){
			maintainDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(m_maintainText)) {
				if("name".equals(searchType)) {
					maintain.setBuildName(m_maintainText);
				} else if("number".equals(searchType)) {
					maintain.setWorkerNum(m_maintainText);
				} 
			}			
			session.removeAttribute("m_maintainText");
			session.removeAttribute("searchType");
			session.removeAttribute("maintainToSelect");
			request.setAttribute("m_maintainText", m_maintainText);
			request.setAttribute("searchType", searchType);
			request.setAttribute("maintainToSelect", workerNum);
		}else if("search".equals(action)){
			if(StringUtil.isNotEmpty(m_maintainText)) {
				if("name".equals(searchType)) {
					maintain.setBuildName(m_maintainText);
				} else if("number".equals(searchType)) {
					maintain.setWorkerNum(m_maintainText);
				} else if("date".equals(searchType)) {
					maintain.setDate(m_maintainText);
				}
				session.setAttribute("searchType", searchType);
				session.setAttribute("m_maintainText", m_maintainText);
				
			} else {
				session.removeAttribute("m_maintainText");
				session.removeAttribute("searchType");
			}
			if(StringUtil.isNotEmpty(maintainId)) {
				maintain.setMaintainId(Integer.parseInt(maintainId));
				session.setAttribute("maintainToSelect", maintainId);
			}else {
				session.removeAttribute("buildToSelect");
			}
		} else if("worker".equals((String)currentUserType)) {
				if(StringUtil.isNotEmpty(m_maintainText)) {
					if("name".equals(searchType)) {
						maintain.setBuildName(m_maintainText);
					} else if("number".equals(searchType)) {
						maintain.setWorkerNum(m_maintainText);
					} else if("date".equals(searchType)) {
						maintain.setDate(m_maintainText);
					}
					session.setAttribute("m_maintainText", m_maintainText);
					session.setAttribute("searchType", searchType);
				}
				if(StringUtil.isEmpty(m_maintainText)) {
					Object o1 = session.getAttribute("m_maintainText");
					Object o2 = session.getAttribute("searchType");
					if(o1!=null) {
						if("name".equals((String)o2)) {
							maintain.setBuildName((String)o1);
						} else if("number".equals((String)o2)) {
							maintain.setWorkerNum((String)o1);
						} else if("date".equals((String)o2)) {
							maintain.setDate((String)o1);
						}
					}
				}else if("dormManager".equals((String)currentUserType)) {
					if(StringUtil.isNotEmpty(m_maintainText)) {
						if("name".equals(searchType)) {
							maintain.setBuildName(m_maintainText);
						} else if("number".equals(searchType)) {
							maintain.setWorkerNum(m_maintainText);
						} else if("date".equals(searchType)) {
							maintain.setDate(m_maintainText);
						}
						session.setAttribute("m_maintainText", m_maintainText);
						session.setAttribute("searchType", searchType);
					}
					if(StringUtil.isEmpty(m_maintainText)) {
						Object o1 = session.getAttribute("m_maintainText");
						Object o2 = session.getAttribute("searchType");
						if(o1!=null) {
							if("name".equals((String)o2)) {
								maintain.setBuildName((String)o1);
							} else if("number".equals((String)o2)) {
								maintain.setWorkerNum((String)o1);
							} else if("date".equals((String)o2)) {
								maintain.setDate((String)o1);
							}
						}
					}
				}
		}
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("dormManager".equals((String)currentUserType)) {
				List<Maintain> maintainList = maintainDao.maintainListWithBuild(con, maintain,maintain.getBuildName());
				request.setAttribute("maintainList", maintainList);
				request.setAttribute("mainPage", "dormManager/maintain.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			}else if("worker".equals((String)currentUserType)) {
				Worker worker = (Worker)(session.getAttribute("currentUser"));
				List<Maintain> maintainList = maintainDao.maintainListWithNumber(con,maintain,worker.getWorkerNum());
				request.setAttribute("maintainList", maintainList);
				request.setAttribute("mainPage", "worker/maintain.jsp");
				request.getRequestDispatcher("mainWorker.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}

	private void maintainDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String maintainId = request.getParameter("maintainId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			maintainDao.maintainDelete(con, maintainId);
			request.getRequestDispatcher("maintain?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void maintainSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String maintainId = request.getParameter("maintainId");
		String workerNum = request.getParameter("workerNum");
		String buildName = request.getParameter("buildName");
		String detail = request.getParameter("detail");
		String date = request.getParameter("date");
		Maintain maintain = new Maintain(workerNum,buildName, detail,date);
		if(StringUtil.isNotEmpty(maintainId)) {
			maintain.setMaintainId(Integer.parseInt(maintainId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(maintainId)) {
				saveNum = maintainDao.maintainUpdate(con, maintain);
			} /*else if(recordDao.haveNameByNumber(con, record.getStudentNumber())){
				request.setAttribute("worker", record);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "admin/recordSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			}*/ else {
				saveNum = maintainDao.maintainAdd(con, maintain);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("maintain?action=list").forward(request, response);
			} else {
				request.setAttribute("maintain", maintain);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "worker/maintainSave.jsp");
				request.getRequestDispatcher("mainWorker.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void maintainPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String maintainId = request.getParameter("maintainId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(maintainId)) {
				Maintain maintain = maintainDao.maintainShow(con, maintainId);
				request.setAttribute("maintain", maintain);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "worker/maintainSave.jsp");
		request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
		
	
}
	
}
