package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.CleanDao;
import com.lero.model.Clean;
import com.lero.model.Worker;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class CleanServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	CleanDao cleanDao = new CleanDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String c_cleanText = request.getParameter("c_cleanText");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		
		Clean clean = new Clean();
		if("preSave".equals(action)) {
			cleanPreSave(request, response);
			return;
		} else if("save".equals(action)){
			cleanSave(request, response);
			return;
		} else if("delete".equals(action)){
			cleanDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(c_cleanText)) {
				if("name".equals(searchType)) {
					clean.setBuildName(c_cleanText);
				} else if("number".equals(searchType)) {
					clean.setWorkerNum(c_cleanText);
				} 
			}			
			session.removeAttribute("c_cleanText");
			session.removeAttribute("searchType");
			request.setAttribute("c_cleanText", c_cleanText);
			request.setAttribute("searchType", searchType);
		}else if("search".equals(action)){
			if(StringUtil.isNotEmpty(c_cleanText)) {
				if("number".equals(searchType)) {
					clean.setWorkerNum(c_cleanText);
				} 
				session.setAttribute("searchType", searchType);
				session.setAttribute("c_cleanText", c_cleanText);
				
			} else {
				session.removeAttribute("searchType");
				session.removeAttribute("c_cleanText");
				
			}
		} else {
			if("dormManager".equals((String)currentUserType)) {
					if(StringUtil.isNotEmpty(c_cleanText)) {
						if("number".equals(searchType)) {
							clean.setWorkerNum(c_cleanText);
						} 
						session.setAttribute("c_cleanText", c_cleanText);
						session.setAttribute("searchType", searchType);
					}
					if(StringUtil.isEmpty(c_cleanText)) {
						Object o1 = session.getAttribute("c_cleanText");
						Object o2 = session.getAttribute("searchType");
						if(o1!=null) {
							if("number".equals((String)o2)) {
								clean.setWorkerNum((String)o1);
							}
						}
					}
				}
		}
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("dormManager".equals((String)currentUserType)) {
				List<Clean> cleanList = cleanDao.cleanList(con, clean);
				//List<Clean> cleanList = cleanDao.cleanList(con, clean);
				//request.setAttribute("BuildName", buildName);
				request.setAttribute("cleanList", cleanList);
				request.setAttribute("mainPage", "dormManager/clean.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			}else if("worker".equals((String)currentUserType)) {
				Worker worker = (Worker)(session.getAttribute("currentUser"));
				List<Clean> cleanList = cleanDao.cleanListWithNumber(con,clean,worker.getWorkerNum());
				request.setAttribute("cleanList", cleanList);
				request.setAttribute("mainPage", "worker/clean.jsp");
				request.getRequestDispatcher("mainWorker.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}

	private void cleanDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String cleanId = request.getParameter("cleanId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			cleanDao.cleanDelete(con, cleanId);
			request.getRequestDispatcher("clean?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void cleanSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String cleanId = request.getParameter("cleanId");
		String workerNum = request.getParameter("workerNum");
		String buildName = request.getParameter("buildName");
		String detail = request.getParameter("detail");
		String date = request.getParameter("date");
		Clean clean = new Clean(workerNum,buildName, detail,date);
		if(StringUtil.isNotEmpty(cleanId)) {
			clean.setCleanId(Integer.parseInt(cleanId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(cleanId)) {
				saveNum = cleanDao.cleanUpdate(con, clean);
			} /*else if(recordDao.haveNameByNumber(con, record.getStudentNumber())){
				request.setAttribute("worker", record);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "admin/recordSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			}*/ else {
				saveNum = cleanDao.cleanAdd(con, clean);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("clean?action=list").forward(request, response);
			} else {
				request.setAttribute("clean", clean);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "worker/cleanSave.jsp");
				request.getRequestDispatcher("mainWorker.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void cleanPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String cleanId = request.getParameter("cleanId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(cleanId)) {
				Clean clean = cleanDao.cleanShow(con, cleanId);
				request.setAttribute("clean", clean);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "worker/cleanSave.jsp");
		request.getRequestDispatcher("mainWorker.jsp").forward(request, response);
		
	
}
	
}
