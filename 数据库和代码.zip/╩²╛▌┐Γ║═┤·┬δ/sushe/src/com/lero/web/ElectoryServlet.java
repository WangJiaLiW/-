package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.ElectoryDao;
import com.lero.model.Electory;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class ElectoryServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	ElectoryDao electoryDao = new ElectoryDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String e_electoryText = request.getParameter("e_electoryText");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		
		Electory electory= new Electory();
		if("preSave".equals(action)) {
			electoryPreSave(request, response);
			return;
		} else if("save".equals(action)){
			electorySave(request, response);
			return;
		} else if("delete".equals(action)){
			electoryDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(e_electoryText)) {
				if("number".equals(searchType)) {
					electory.setDormNum(e_electoryText);
				} else if("name".equals(searchType)) {
					electory.setName(e_electoryText);
				} 
			}			
			session.removeAttribute("e_electoryText");
			session.removeAttribute("searchType");
			request.setAttribute("e_electoryText", e_electoryText);
			request.setAttribute("searchType", searchType);
		}else if("search".equals(action)){
			if(StringUtil.isNotEmpty(e_electoryText)) {
				if("name".equals(searchType)) {
					electory.setName(e_electoryText);
				} else if("number".equals(searchType)){
					electory.setDormNum(e_electoryText);
				}
				session.setAttribute("searchType", searchType);
				session.setAttribute("e_electoryText", e_electoryText);
				
			} else {
				session.removeAttribute("searchType");
				session.removeAttribute("e_electoryText");
				
			}
		} 
			 if("teacher".equals((String)currentUserType)) {
					if(StringUtil.isNotEmpty(e_electoryText)) {
						if("name".equals(searchType)) {
							electory.setName(e_electoryText);
						} else if("number".equals(searchType)) {
							electory.setDormNum(e_electoryText);
						} 
						session.setAttribute("e_electoryText", e_electoryText);
						session.setAttribute("searchType", searchType);
					}
					if(StringUtil.isEmpty(e_electoryText)) {
						Object o1 = session.getAttribute("e_electoryText");
						Object o2 = session.getAttribute("searchType");
						if(o1!=null) {
							if("name".equals((String)o2)) {
								electory.setName((String)o1);
							} else if("number".equals((String)o2)) {
								electory.setDormNum((String)o1);
							} 
						}
					}
			 
			 }
			 
			 
		
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("teacher".equals((String)currentUserType)) {
				List<Electory> electoryList=null;
				if(StringUtil.isNotEmpty(electory.getDormNum())){
					electoryList = electoryDao.electoryListWithNumber(con, electory, electory.getDormNum());
				}else if(StringUtil.isNotEmpty(electory.getName())){
					electoryList = electoryDao.electoryListWithName(con, electory, electory.getName());
				}else{
					electoryList = electoryDao.electoryList(con, electory);
				}
				request.setAttribute("electoryList", electoryList);
				request.setAttribute("mainPage", "teacher/electory.jsp");
				request.getRequestDispatcher("mainTeacher.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}

	private void electoryDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String electoryId = request.getParameter("electoryId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			electoryDao.electoryDelete(con, electoryId);
			request.getRequestDispatcher("electory?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void electorySave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String electoryId = request.getParameter("electoryId");
		String dormNum = request.getParameter("dormNum");
		String name = request.getParameter("name");
		String detail = request.getParameter("detail");
	
		Electory electory = new Electory(dormNum,name, detail);
		if(StringUtil.isNotEmpty(electoryId)) {
			electory.setElectoryId(Integer.parseInt(electoryId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(electoryId)) {
				saveNum = electoryDao.electoryUpdate(con, electory);
			}else {
				saveNum = electoryDao.electoryAdd(con, electory);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("electory?action=list").forward(request, response);
			} else {
				request.setAttribute("electory", electory);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "teacher/electorySave.jsp");
				request.getRequestDispatcher("mainTeacher.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void electoryPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String electoryId = request.getParameter("electoryId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(electoryId)) {
				Electory electory = electoryDao.electoryShow(con, electoryId);
				request.setAttribute("electory", electory);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "teacher/electorySave.jsp");
		request.getRequestDispatcher("mainTeacher.jsp").forward(request, response);
		
	
}
	
}
