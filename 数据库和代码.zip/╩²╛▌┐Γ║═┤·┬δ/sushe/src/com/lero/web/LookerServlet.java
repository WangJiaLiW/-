package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.LookerDao;
import com.lero.model.Looker;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class LookerServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	LookerDao lookerDao = new LookerDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String l_lookerText = request.getParameter("l_lookerText");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		
		Looker looker = new Looker();
		if("preSave".equals(action)) {
			lookerPreSave(request, response);
			return;
		} else if("save".equals(action)){
			lookerSave(request, response);
			return;
		} else if("delete".equals(action)){
			lookerDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(l_lookerText)) {
				if("name".equals(searchType)) {
					looker.setBuildName(l_lookerText);
				} else if("number".equals(searchType)) {
					looker.setStudentNum(l_lookerText);
				} 
			}			
			session.removeAttribute("l_lookerText");
			session.removeAttribute("searchType");
			request.setAttribute("l_lookerText", l_lookerText);
			request.setAttribute("searchType", searchType);
		}else if("search".equals(action)){
			if(StringUtil.isNotEmpty(l_lookerText)) {
				if("number".equals(searchType)) {
					looker.setStudentNum(l_lookerText);
				}
				session.setAttribute("searchType", searchType);
				session.setAttribute("l_lookerText", l_lookerText);
				
			} else {
				session.removeAttribute("l_lookerText");
				session.removeAttribute("searchType");
			}
		} else {
			 if("dormManager".equals((String)currentUserType)) {
					if(StringUtil.isNotEmpty(l_lookerText)) {
						if("number".equals(searchType)) {
							looker.setStudentNum(l_lookerText);
						}
						session.setAttribute("l_lookerText",l_lookerText);
						session.setAttribute("searchType", searchType);
					}
					if(StringUtil.isEmpty(l_lookerText)) {
						Object o1 = session.getAttribute("l_lookerText");
						Object o2 = session.getAttribute("searchType");
						if(o1!=null) {
							if("number".equals((String)o2)) {
								looker.setStudentNum((String)o1);
							}
						}
					}
				}
		}
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("dormManager".equals((String)currentUserType)) {
				List<Looker> lookerList = lookerDao.lookerList(con, looker);
				//request.setAttribute("BuildName", buildName);
				request.setAttribute("lookerList", lookerList);
				request.setAttribute("mainPage", "dormManager/looker.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}

	private void lookerDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String lookerId = request.getParameter("lookerId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			lookerDao.lookerDelete(con, lookerId);
			request.getRequestDispatcher("looker?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void lookerSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String lookerId = request.getParameter("lookerId");
		String studentNum = request.getParameter("studentNum");
		String buildName = request.getParameter("buildName");
		String detail = request.getParameter("detail");
		String date = request.getParameter("date");
		
		Looker looker = new Looker(studentNum,buildName, detail,date);
		if(StringUtil.isNotEmpty(lookerId)) {
			looker.setLookerId(Integer.parseInt(lookerId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(lookerId)) {
				saveNum = lookerDao.lookerUpdate(con, looker);
			} /*else if(recordDao.haveNameByNumber(con, record.getStudentNumber())){
				request.setAttribute("worker", record);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "admin/recordSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			}*/ else {
				saveNum = lookerDao.lookerAdd(con, looker);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("looker?action=list").forward(request, response);
			} else {
				request.setAttribute("looker", looker);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "dormManager/lookerSave.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void lookerPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String lookerId = request.getParameter("lookerId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(lookerId)) {
				Looker looker = lookerDao.lookerShow(con, lookerId);
				request.setAttribute("looker", looker);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "dormManager/lookerSave.jsp");
		request.getRequestDispatcher("mainManager.jsp").forward(request, response);
		
	
}
	
}
