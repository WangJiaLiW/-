package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.TeacherDao;
import com.lero.model.Teacher;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class TeacherServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	TeacherDao teacherDao = new TeacherDao();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String t_teacherText = request.getParameter("t_teacherText");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		Teacher teacher = new Teacher();
		if("preSave".equals(action)) {
			teacherPreSave(request, response);
			return;
		} else if("save".equals(action)){
			teacherSave(request, response);
			return;
		} else if("delete".equals(action)){
			teacherDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(t_teacherText)) {
				if("name".equals(searchType)) {
					teacher.setName(t_teacherText);
				} else if("number".equals(searchType)) {
					teacher.setTeacherNum(t_teacherText);
				} 
			}
			session.removeAttribute("t_teacherText");
			session.removeAttribute("searchType");
			request.setAttribute("t_teacherText", t_teacherText);
			request.setAttribute("searchType", searchType);
		} else if("search".equals(action)){
			if(StringUtil.isNotEmpty(t_teacherText)) {
				if("name".equals(searchType)) {
					teacher.setName(t_teacherText);
				} else if("number".equals(searchType)) {
					teacher.setTeacherNum(t_teacherText);
				}
				session.setAttribute("t_teacherText", t_teacherText);
				session.setAttribute("searchType", searchType);
			} else {
				session.removeAttribute("t_teacherText");
				session.removeAttribute("searchType");
			}
		} else {
			if("admin".equals((String)currentUserType)) {
				if(StringUtil.isNotEmpty(t_teacherText)) {
					if("name".equals(searchType)) {
						teacher.setName(t_teacherText);
					} else if("number".equals(searchType)) {
						teacher.setTeacherNum(t_teacherText);
					} 
					session.setAttribute("t_teacherText", t_teacherText);
					session.setAttribute("searchType", searchType);
				}
			}/* else if("dormManager".equals((String)currentUserType)) {
				if(StringUtil.isNotEmpty(w_workerText)) {
					if("name".equals(searchType)) {
						worker.setName(w_workerText);
					} else if("number".equals(searchType)) {
						worker.setWorkerNum(w_workerText);
					} 
					session.setAttribute("w_workerText", w_workerText);
					session.setAttribute("searchType", searchType);
				}
				if(StringUtil.isEmpty(w_workerText)) {
					Object o1 = session.getAttribute("w_workerText");
					Object o2 = session.getAttribute("searchType");
					if(o1!=null) {
						if("name".equals((String)o2)) {
							worker.setName((String)o1);
						} else if("number".equals((String)o2)) {
							worker.setWorkerNum((String)o1);
						} 
					}
				}
			}*/
		}
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("admin".equals((String)currentUserType)) {
				List<Teacher> teacherList = teacherDao.teacherList(con, teacher);
				request.setAttribute("teacherList", teacherList);
				request.setAttribute("mainPage", "admin/teacher.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void teacherDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String teacherId = request.getParameter("teacherId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			teacherDao.teacherDelete(con, teacherId);
			request.getRequestDispatcher("teacher?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void teacherSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String teacherId = request.getParameter("teacherId");
		String teacherNum = request.getParameter("teacherNum");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		Teacher teacher = new Teacher(teacherNum,password, name);
		if(StringUtil.isNotEmpty(teacherId)) {
			teacher.setTeacherId(Integer.parseInt(teacherId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(teacherId)) {
				saveNum = teacherDao.teacherUpdate(con, teacher);
			} else if(teacherDao.haveNameByNumber(con, teacher.getTeacherNum())){
				request.setAttribute("teacher", teacher);
				request.setAttribute("error", "错误");
				request.setAttribute("mainPage", "admin/teacherSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			} else {
				saveNum = teacherDao.teacherAdd(con, teacher);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("teacher?action=list").forward(request, response);
			} else {
				request.setAttribute("teacher", teacher);
				request.setAttribute("error", "错误");
				request.setAttribute("mainPage", "admin/teacherSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void teacherPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String teacherId = request.getParameter("teacherId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(teacherId)) {
				Teacher teacher = teacherDao.teacherShow(con, teacherId);
				request.setAttribute("teacher", teacher);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "admin/teacherSave.jsp");
		request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
	}

	
}
