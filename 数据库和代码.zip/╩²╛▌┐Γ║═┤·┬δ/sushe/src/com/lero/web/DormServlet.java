package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.DormDao;
import com.lero.model.Dorm;
import com.lero.model.PageBean;
import com.lero.util.DbUtil;
import com.lero.util.PropertiesUtil;
import com.lero.util.StringUtil;

public class DormServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	DormDao dormDao = new DormDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String d_dormText = request.getParameter("d_dormText");
		String searchType = request.getParameter("searchType");
		String page = request.getParameter("page");
		String action = request.getParameter("action");
		Object currentUserType = session.getAttribute("currentUserType");
		Dorm dorm = new Dorm();
		if("preSave".equals(action)) {
			dormPreSave(request, response);
			return;
		} else if("save".equals(action)){
			dormSave(request, response);
			return;
		} else if("delete".equals(action)){
			dormDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(d_dormText)) {
			if("grade".equals(searchType)) {
				dorm.setGrade(d_dormText);
			} else if("dormNum".equals(searchType)) {
				dorm.setDormNum(d_dormText);
			}
		}
			session.removeAttribute("d_dormText");
			session.removeAttribute("searchType");
			request.setAttribute("d_dormText", d_dormText);
			request.setAttribute("searchType", searchType);
		}else if("search".equals(action)){
			if(StringUtil.isNotEmpty(d_dormText)) {
				if("grade".equals(searchType)) {
					dorm.setGrade(d_dormText);
				} else if("number".equals(searchType)){
					dorm.setDormNum(d_dormText);
				}
				session.setAttribute("searchType", searchType);
				session.setAttribute("d_dormText", d_dormText);
			} else {
				session.removeAttribute("searchType");
				session.removeAttribute("d_dormText");
			}
		} else {
			if("teacher".equals((String)currentUserType)){
					if(StringUtil.isNotEmpty(d_dormText)) {
						if("grade".equals(searchType)) {
							dorm.setGrade(d_dormText);
						} else if("number".equals(searchType)){
							dorm.setDormNum(d_dormText);
						}
						session.setAttribute("searchType", searchType);
						session.setAttribute("d_dormText", d_dormText);
					}
					if(StringUtil.isEmpty(d_dormText)) {
						Object o1 = session.getAttribute("d_dormText");
						Object o2 = session.getAttribute("searchType");
						if(o1!=null) {
							if("number".equals((String)o2)) {
								dorm.setDormNum((String)o1);
							} else if("grade".equals((String)o2)) {
								dorm.setGrade((String)o1);
							}
						}
					}
				}
		}
			 if(StringUtil.isEmpty(page)) {
					page="1";
				}
		
		Connection con = null;
		PageBean pageBean = new PageBean(Integer.parseInt(page), Integer.parseInt(PropertiesUtil.getValue("pageSize")));
		request.setAttribute("pageSize", pageBean.getPageSize());
		request.setAttribute("page", pageBean.getPage());
		try {
			con=dbUtil.getCon();
			List<Dorm> dormList = dormDao.dormList(con, pageBean, dorm);
			int total=dormDao.dormCount(con, dorm);
			String pageCode = this.genPagation(total, Integer.parseInt(page), Integer.parseInt(PropertiesUtil.getValue("pageSize")));
			request.setAttribute("pageCode", pageCode);
			request.setAttribute("dormList", dormList);
			request.setAttribute("mainPage", "teacher/dorm.jsp");
			request.getRequestDispatcher("mainTeacher.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	
	
	private void dormDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String dormId = request.getParameter("dormId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			dormDao.dormDelete(con, dormId);
			request.getRequestDispatcher("dorm?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void dormSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String dormId = request.getParameter("dormId");
		String dormNum = request.getParameter("dormNum");
		String grade =request.getParameter("grade");
		String name = request.getParameter("name");
		String detail = request.getParameter("detail");
		String date = request.getParameter("date");
		Dorm dorm = new Dorm(dormNum,name, grade,date,detail);
		if(StringUtil.isNotEmpty(dormId)) {
			dorm.setDormId(Integer.parseInt(dormId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(dormId)) {
				saveNum = dormDao.dormUpdate(con, dorm);
			} else if(dormDao.havedormNumByGrade(con, dorm.getGrade())){
				request.setAttribute("dorm", dorm);
				request.setAttribute("error", "�Ѵ���");
				request.setAttribute("mainPage", "teacher/dormSave.jsp");
				request.getRequestDispatcher("mainTeacher.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			
			
			}else {
				saveNum = dormDao.dormAdd(con, dorm);
			}
			
			
			if(saveNum > 0) {
				request.getRequestDispatcher("dorm?action=list").forward(request, response);
			} else {
				request.setAttribute("dorm", dorm);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "teacher/dormSave.jsp");
				request.getRequestDispatcher("mainTeacher.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void dormPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String dormId = request.getParameter("dormId");
		if(StringUtil.isNotEmpty(dormId)) {
		Connection con = null;
		try {
			con = dbUtil.getCon();
			Dorm dorm = dormDao.dormShow(con, dormId);
				request.setAttribute("dorm", dorm); 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		}
		request.setAttribute("mainPage", "teacher/dormSave.jsp");
		request.getRequestDispatcher("mainTeacher.jsp").forward(request, response);
		
	
}
	
	private String genPagation(int totalNum, int currentPage, int pageSize){
		int totalPage = totalNum%pageSize==0?totalNum/pageSize:totalNum/pageSize+1;
		StringBuffer pageCode = new StringBuffer();
		pageCode.append("<li><a href='dorm?page=1'>首页</a></li>");
		if(currentPage==1) {
			pageCode.append("<li class='disabled'><a href='#'>上一页</a></li>");
		}else {
			pageCode.append("<li><a href='dorm?page="+(currentPage-1)+"'>上一页</a></li>");
		}
		for(int i=currentPage-2;i<=currentPage+2;i++) {
			if(i<1||i>totalPage) {
				continue;
			}
			if(i==currentPage) {
				pageCode.append("<li class='active'><a href='#'>"+i+"</a></li>");
			} else {
				pageCode.append("<li><a href='dorm?page="+i+"'>"+i+"</a></li>");
			}
		}
		if(currentPage==totalPage) {
			pageCode.append("<li class='disabled'><a href='#'>下一页</a></li>");
		} else {
			pageCode.append("<li><a href='dorm?page="+(currentPage+1)+"'>下一页</a></li>");
		}
		pageCode.append("<li><a href='dorm?page="+totalPage+"'>尾页</a></li>");
		return pageCode.toString();
	}
	
	
}
