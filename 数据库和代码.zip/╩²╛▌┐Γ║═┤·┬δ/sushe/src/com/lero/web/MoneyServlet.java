package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.MoneyDao;
import com.lero.model.Money;
import com.lero.model.Student;
import com.lero.model.Worker;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class MoneyServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	MoneyDao moneyDao = new MoneyDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String m_moneyText = request.getParameter("m_moneyText");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		Money money = new Money();
		if("preSave".equals(action)) {
			moneyPreSave(request, response);
			return;
		} else if("save".equals(action)){
			moneySave(request, response);
			return;
		} else if("delete".equals(action)){
			moneyDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(m_moneyText)) {
				if("name".equals(searchType)) {
					money.setName(m_moneyText);
				} else if("number".equals(searchType)) {
					money.setStudentNum(m_moneyText);
				} 
			}
			/*if(StringUtil.isNotEmpty(recordId)) {
				record.setDormBuildId(Integer.parseInt(recordId));
			}
			session.removeAttribute("r_recordText");
			session.removeAttribute("searchType");
			session.removeAttribute("buildToSelect");
			request.setAttribute("r_recordText", r_recordText);
			request.setAttribute("searchType", searchType);
			request.setAttribute("buildToSelect", dormBuildId);*/
		} else if("search".equals(action)){
			if(StringUtil.isNotEmpty(m_moneyText)) {
				if("name".equals(searchType)) {
					money.setName(m_moneyText);
				} else if("number".equals(searchType)) {
					money.setStudentNum(m_moneyText);
				}
				session.setAttribute("m_moneyText", m_moneyText);
				session.setAttribute("searchType", searchType);
			} else {
				session.removeAttribute("m_moneyText");
				session.removeAttribute("searchType");
			}
		} 
		
		
		
		//���ø������ݵ�����
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("student".equals((String)currentUserType)) {
				Student student = (Student)(session.getAttribute("currentUser"));
				List<Money> moneyList = moneyDao.moneyListWithNumber(con, money, student.getStuNumber());
				/*request.setAttribute("dormBuildList", moneyDao.dormBuildList(con));*/
				request.setAttribute("moneyList", moneyList);
				request.setAttribute("mainPage", "student/money.jsp");
				request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
			}else if("worker".equals((String)currentUserType)) {
				Worker worker=(Worker)(session.getAttribute("currentUser"));
				List<Money> moneyList = moneyDao.moneyListWithNum(con, money,worker.getWorkerNum());
				request.setAttribute("moneyList", moneyList);
				request.setAttribute("mainPage", "worker/money.jsp");
				request.getRequestDispatcher("mainWorker.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void moneyDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String moneyId = request.getParameter("moneyId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			moneyDao.moneyDelete(con, moneyId);
			request.getRequestDispatcher("money?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void moneySave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String moneyId = request.getParameter("moneyId");
		String name = request.getParameter("name");
		String amount = request.getParameter("amount");
		String studentNum=request.getParameter("studentNum");
		String workerNum = request.getParameter("workerNum");
		Money money = new Money(name, amount,studentNum,workerNum);
		if(StringUtil.isNotEmpty(moneyId)) {
			money.setMoneyId(Integer.parseInt(moneyId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(moneyId)) {
				saveNum = moneyDao.moneyUpdate(con, money);
			} /*else if(recordDao.haveNameByNumber(con, record.getStudentNumber())){
				request.setAttribute("worker", record);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "admin/recordSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			}*/ else{
				saveNum = moneyDao.moneyAdd(con, money);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("money?action=list").forward(request, response);
			} else {
				request.setAttribute("worker", money);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "worker/moneySave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void moneyPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String moneyId = request.getParameter("moneyId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(moneyId)) {
				Money money = moneyDao.moneyShow(con, moneyId);
				request.setAttribute("money", money);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "worker/moneySave.jsp");
		request.getRequestDispatcher("mainWorker.jsp").forward(request, response);
		
	
}	
}

