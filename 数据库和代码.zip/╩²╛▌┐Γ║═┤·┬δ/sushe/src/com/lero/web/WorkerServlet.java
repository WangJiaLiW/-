package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.WorkerDao;
import com.lero.model.Worker;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class WorkerServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	WorkerDao workerDao = new WorkerDao();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}
//doget() 和 dopost()分别对应 http协议中的 GET和 POST方法，
	//请求是 GET方法就调用 doget() ，请求是 POST方法就调用 dopost()方法。
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String w_workerText = request.getParameter("w_workerText");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		Worker worker = new Worker();
		if("preSave".equals(action)) {
			workerPreSave(request, response);
			return;
		} else if("save".equals(action)){
			workerSave(request, response);
			return;
		} else if("delete".equals(action)){
			workerDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(w_workerText)) {
				if("name".equals(searchType)) {
					worker.setName(w_workerText);
				} else if("number".equals(searchType)) {
					worker.setWorkerNum(w_workerText);
				} 
			}
			session.removeAttribute("w_workerText");//删除session中的某一个用户状态属性。
			session.removeAttribute("searchType");
			request.setAttribute("w_workerText", w_workerText);//表示从request范围取得设置的属性
			request.setAttribute("searchType", searchType);
		} else if("search".equals(action)){
			if(StringUtil.isNotEmpty(w_workerText)) {
				if("name".equals(searchType)) {
					worker.setName(w_workerText);
				} else if("number".equals(searchType)) {
					worker.setWorkerNum(w_workerText);
				}
				session.setAttribute("w_workerText", w_workerText);
				session.setAttribute("searchType", searchType);
			} else {
				session.removeAttribute("w_workerText");
				session.removeAttribute("searchType");
			}
		} else {
			if("admin".equals((String)currentUserType)) {
				if(StringUtil.isNotEmpty(w_workerText)) {
					if("name".equals(searchType)) {
						worker.setName(w_workerText);
					} else if("number".equals(searchType)) {
						worker.setWorkerNum(w_workerText);
					} 
					session.setAttribute("w_workerText", w_workerText);
					session.setAttribute("searchType", searchType);
				}
			} else if("dormManager".equals((String)currentUserType)) {
				if(StringUtil.isNotEmpty(w_workerText)) {
					if("name".equals(searchType)) {
						worker.setName(w_workerText);
					} else if("number".equals(searchType)) {
						worker.setWorkerNum(w_workerText);
					} 
					session.setAttribute("w_workerText", w_workerText);
					session.setAttribute("searchType", searchType);
				}
				if(StringUtil.isEmpty(w_workerText)) {
					Object o1 = session.getAttribute("w_workerText");
					Object o2 = session.getAttribute("searchType");
					if(o1!=null) {
						if("name".equals((String)o2)) {
							worker.setName((String)o1);
						} else if("number".equals((String)o2)) {
							worker.setWorkerNum((String)o1);
						} 
					}
				}
			}
		}
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("admin".equals((String)currentUserType)) {
				List<Worker> workerList = workerDao.workerList(con, worker);
				request.setAttribute("workerList", workerList);
				request.setAttribute("mainPage", "admin/worker.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void workerDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String workerId = request.getParameter("workerId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			workerDao.workerDelete(con, workerId);
			request.getRequestDispatcher("worker?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void workerSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String workerId = request.getParameter("workerId");
		String workerNum = request.getParameter("workerNum");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String tel = request.getParameter("tel");
		Worker worker = new Worker(workerNum,password, name,sex,Integer.parseInt(tel));
		if(StringUtil.isNotEmpty(workerId)) {
			worker.setWorkerId(Integer.parseInt(workerId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(workerId)) {
				saveNum = workerDao.workerUpdate(con, worker);
			} else if(workerDao.haveNameByNumber(con, worker.getWorkerNum())){
				request.setAttribute("worker", worker);
				request.setAttribute("error", "错误");
				request.setAttribute("mainPage", "admin/workerSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			} else {
				saveNum = workerDao.workerAdd(con, worker);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("worker?action=list").forward(request, response);
			} else {
				request.setAttribute("worker", worker);
				request.setAttribute("error", "淇濆瓨澶辫触");
				request.setAttribute("mainPage", "admin/workerSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void workerPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String workerId = request.getParameter("workerId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(workerId)) {
				Worker worker = workerDao.workerShow(con, workerId);
				request.setAttribute("worker", worker);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "admin/workerSave.jsp");
		request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
	}

	
}
