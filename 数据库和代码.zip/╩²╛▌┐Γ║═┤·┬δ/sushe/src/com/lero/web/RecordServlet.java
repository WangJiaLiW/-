package com.lero.web;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.DormBuildDao;
import com.lero.dao.RecordDao;
import com.lero.model.DormManager;
import com.lero.model.Record;
import com.lero.model.Student;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class RecordServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	DbUtil dbUtil = new DbUtil();
	RecordDao recordDao = new RecordDao();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		Object currentUserType = session.getAttribute("currentUserType");
		String r_recordText = request.getParameter("r_recordText");
		String studentNumber=request.getParameter("studentNumber");
		String searchType = request.getParameter("searchType");
		String action = request.getParameter("action");
		Record record = new Record();
		if("preSave".equals(action)) {
			recordPreSave(request, response);
			return;
		} else if("save".equals(action)){
			recordSave(request, response);
			return;
		} else if("delete".equals(action)){
			recordDelete(request, response);
			return;
		} else if("list".equals(action)) {
			if(StringUtil.isNotEmpty(r_recordText)) {
				if("name".equals(searchType)) {
					record.setStudentName(r_recordText);
				} else if("number".equals(searchType)) {
					record.setStudentNumber(r_recordText);
				}
			}
			session.removeAttribute("r_recordText");
			session.removeAttribute("searchType");
			request.setAttribute("r_recordText", r_recordText);
			request.setAttribute("searchType", searchType);
		} else if("search".equals(action)){
			if(StringUtil.isNotEmpty(r_recordText)) {
			 if("number".equals(searchType)) {
					record.setStudentNumber(r_recordText);
				}
			 	session.setAttribute("searchType", searchType);
				session.setAttribute("r_recordText", r_recordText);
				
			} else {
				session.removeAttribute("searchType");
				session.removeAttribute("r_recordText");
				
			}
		/*	if(StringUtil.isNotEmpty(dormBuildId)) {
				record.setDormBuildId(dormBuildId);
				session.setAttribute("buildToSelect", dormBuildId);
			}else {
				session.removeAttribute("buildToSelect");
			}*/
		} else {
			if("dormManager".equals((String)currentUserType)) {
				if(StringUtil.isNotEmpty(r_recordText)) {
					if("number".equals(searchType)) {
						record.setStudentNumber(r_recordText);
				} 
				session.setAttribute("r_recordText", r_recordText);
				session.setAttribute("searchType", searchType);
			}
			if(StringUtil.isEmpty(r_recordText)) {
				Object o1 = session.getAttribute("r_recordText");
				Object o2 = session.getAttribute("searchType");
				if(o1!=null) {
					if("number".equals((String)o2)) {
						record.setStudentNumber((String)o1);
					} 
				}
			}
		}
	}	
		
		Connection con = null;
		try {
			con=dbUtil.getCon();
			if("dormManager".equals((String)currentUserType)) {
				DormManager manager = (DormManager)(session.getAttribute("currentUser"));
				int buildId = manager.getDormBuildId();
				String buildName = DormBuildDao.dormBuildName(con, buildId);
				List<Record> recordList = recordDao.recordList(con, record);
				//request.setAttribute("dormBuildName", buildName);
				request.setAttribute("recordList", recordList);
				request.setAttribute("mainPage", "dormManager/record.jsp");
				request.getRequestDispatcher("mainManager.jsp").forward(request, response);
			} else if("student".equals((String)currentUserType)) {
				Student student = (Student)(session.getAttribute("currentUser"));
				List<Record> recordList = recordDao.recordListWithNumber(con, record, student.getStuNumber());
				request.setAttribute("recordList", recordList);
				request.setAttribute("mainPage", "student/record.jsp");
				request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void recordDelete(HttpServletRequest request,
			HttpServletResponse response) {
		String recordId = request.getParameter("recordId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			recordDao.recordDelete(con, recordId);
			request.getRequestDispatcher("record?action=list").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void recordSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String recordId = request.getParameter("recordId");
		String studentNumber = request.getParameter("studentNumber");
		String studentName = request.getParameter("studentName");
		String dormbuildId = request.getParameter("dormBuildId");
		String date = request.getParameter("date");
		String detail = request.getParameter("detail");
		String dormName=request.getParameter("dormName");
		Record record = new Record(studentNumber,studentName, Integer.parseInt(dormbuildId),  date, detail,dormName);
		if(StringUtil.isNotEmpty(recordId)) {
			record.setRecordId(Integer.parseInt(recordId));
		}
		Connection con = null;
		try {
			con = dbUtil.getCon();
			int saveNum = 0;
			if(StringUtil.isNotEmpty(recordId)) {
				saveNum = recordDao.recordUpdate(con, record);
			} /*else if(recordDao.haveNameByNumber(con, record.getStudentNumber())){
				request.setAttribute("worker", record);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "admin/recordSave.jsp");
				request.getRequestDispatcher("mainAdmin.jsp").forward(request, response);
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return;
			}*/ else {
				saveNum = recordDao.recordAdd(con, record);
			}
			if(saveNum > 0) {
				request.getRequestDispatcher("record?action=list").forward(request, response);
			} else {
				request.setAttribute("record", record);
				request.setAttribute("error", "����");
				request.setAttribute("mainPage", "student/recordSave.jsp");
				request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void recordPreSave(HttpServletRequest request,
			HttpServletResponse response)throws ServletException, IOException {
		String recordId = request.getParameter("recordId");
		Connection con = null;
		try {
			con = dbUtil.getCon();
			if (StringUtil.isNotEmpty(recordId)) {
				Record record = recordDao.recordShow(con, recordId);
				request.setAttribute("record", record);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		request.setAttribute("mainPage", "student/recordSave.jsp");
		request.getRequestDispatcher("mainStudent.jsp").forward(request, response);
		
	
}
	
}
