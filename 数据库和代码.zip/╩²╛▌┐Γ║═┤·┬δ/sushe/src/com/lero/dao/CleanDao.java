package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lero.model.Clean;
import com.lero.util.StringUtil;

public class CleanDao {
	public List<Clean> cleanList(Connection con, Clean c_clean)throws Exception {
		List<Clean> cleanList = new ArrayList<Clean>();
		StringBuffer sb = new StringBuffer("select * from t_clean t1");
		if(StringUtil.isNotEmpty(c_clean.getBuildName())) {
			sb.append(" and t1.buildName like '%"+c_clean.getBuildName()+"%'");
		} else if(StringUtil.isNotEmpty(c_clean.getWorkerNum())) {
			sb.append(" and t1.workerNum like '%"+c_clean.getWorkerNum()+"%'");
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Clean clean=new Clean();
			clean.setCleanId(rs.getInt("cleanId"));
			clean.setWorkerNum(rs.getString("workerNum"));
			clean.setBuildName(rs.getString("buildName"));
			clean.setDetail(rs.getString("detail"));
			clean.setDate(rs.getString("date"));
			cleanList.add(clean);
		}
		return cleanList;
	}
	
	public List<Clean> cleanListWithBuild(Connection con, Clean c_clean, String buildName)throws Exception {
		List<Clean> cleanList = new ArrayList<Clean>();
		StringBuffer sb = new StringBuffer("select * from t_clean t1");
		/*sb.append(" and t1.buildName="+buildName);*/
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Clean clean=new Clean();
			clean.setCleanId(rs.getInt("cleanId"));
			clean.setWorkerNum(rs.getString("workerNum"));
			clean.setBuildName(rs.getString("buildName"));
			clean.setDetail(rs.getString("detail"));
			clean.setDate(rs.getString("date"));
			cleanList.add(clean);
		}
		return cleanList;
	}
	
	public List<Clean> cleanListWithNumber(Connection con, Clean c_clean, String workerNum)throws Exception {
		List<Clean> cleanList = new ArrayList<Clean>();
		StringBuffer sb = new StringBuffer("select * from t_clean t1");
		/*if(StringUtil.isNotEmpty(workerNum)) {
			sb.append(" and t1.workerNum ="+workerNum);
		} */
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Clean clean=new Clean();
			clean.setCleanId(rs.getInt("cleanId"));
			clean.setWorkerNum(rs.getString("workerNum"));
			clean.setBuildName(rs.getString("buildName"));
			clean.setDetail(rs.getString("detail"));
			clean.setDate(rs.getString("date"));
			cleanList.add(clean);
		}
		return cleanList;
	}	
	
	public List<Clean> cleanListwithNum(Connection con, Clean c_clean, String workerNum)throws Exception {
		List<Clean> cleanList = new ArrayList<Clean>();
		StringBuffer sb = new StringBuffer("select * from t_clean t1");
		if(StringUtil.isNotEmpty(workerNum)) {
			sb.append(" and t1.workerNum ="+workerNum);
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Clean clean=new Clean();
			clean.setCleanId(rs.getInt("cleanId"));
			clean.setWorkerNum(rs.getString("workerNum"));
			clean.setBuildName(rs.getString("buildName"));
			clean.setDetail(rs.getString("detail"));
			clean.setDate(rs.getString("date"));
			cleanList.add(clean);
		}
		return cleanList;
	}	
/*	public List<DormBuild> dormBuildList(Connection con)throws Exception {
		List<DormBuild> dormBuildList = new ArrayList<DormBuild>();
		String sql = "select * from t_dormBuild";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			DormBuild dormBuild=new DormBuild();
			dormBuild.setDormBuildId(rs.getInt("dormBuildId"));
			dormBuild.setDetail(rs.getString("dormBuildDetail"));
			dormBuildList.add(dormBuild);
		}
		return dormBuildList;
	}*/

	public int cleanCount(Connection con, Clean c_clean)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from t_clean t1");
		if(StringUtil.isNotEmpty(c_clean.getBuildName())) {
			sb.append(" and t1.buildName like '%"+c_clean.getBuildName()+"%'");
		} else if(StringUtil.isNotEmpty(c_clean.getWorkerNum())) {
			sb.append(" and t1.workerNum like '%"+c_clean.getWorkerNum()+"%'");
		} 
		if(c_clean.getCleanId()!=0) {
			sb.append(" and t1.cleanId="+c_clean.getCleanId());
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
	if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}
	
	public Clean cleanShow(Connection con, String cleanId)throws Exception {
		String sql = "select * from t_clean t1 where t1.cleanId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, cleanId);
		ResultSet rs=pstmt.executeQuery();
		Clean clean = new Clean();
		while(rs.next()) {
			clean.setCleanId(rs.getInt("cleanId"));
			clean.setWorkerNum(rs.getString("workerNum"));
			clean.setBuildName(rs.getString("buildName"));
			clean.setDetail(rs.getString("detail"));
			clean.setDate(rs.getString("date"));
		}
		return clean;
	}
	
	public int cleanAdd(Connection con, Clean clean)throws Exception {
		String sql = "insert into t_clean values(null,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, clean.getWorkerNum());
		pstmt.setString(2, clean.getBuildName());
		pstmt.setString(3, clean.getDetail());
		pstmt.setString(4, clean.getDate());
		return pstmt.executeUpdate();
	}
	
	public int cleanDelete(Connection con, String cleanId)throws Exception {
		String sql = "delete from t_clean where cleanId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, cleanId);
		return pstmt.executeUpdate();
	}
	
	public int cleanUpdate(Connection con, Clean clean)throws Exception {
		String sql = "update t_clean set workerNum=?,buildName=?,detail=?,date=? where cleanId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, clean.getWorkerNum());
		pstmt.setString(2, clean.getBuildName());
		pstmt.setString(3, clean.getDetail());
		pstmt.setString(4, clean.getDate());
		pstmt.setInt(5, clean.getCleanId());
		return pstmt.executeUpdate();
	}
	
	
}
