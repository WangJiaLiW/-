package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.lero.model.Looker;
import com.lero.util.StringUtil;

public class LookerDao {
	public List<Looker> lookerList(Connection con, Looker l_looker)throws Exception {
		List<Looker> lookerList = new ArrayList<Looker>();
		StringBuffer sb = new StringBuffer("select * from t_looker t1");
		if(StringUtil.isNotEmpty(l_looker.getBuildName())) {
			sb.append(" and t1.buildName like '%"+l_looker.getBuildName()+"%'");
		} else if(StringUtil.isNotEmpty(l_looker.getStudentNum())) {
			sb.append(" and t1.studentNum like '%"+l_looker.getStudentNum()+"%'");
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Looker looker=new Looker();
			looker.setLookerId(rs.getInt("lookerId"));
			looker.setStudentNum(rs.getString("studentNum"));
			looker.setDate(rs.getString("date"));
			looker.setDetail(rs.getString("detail"));
			looker.setBuildName(rs.getString("buildName"));
		//	looker.setDormBuildId(rs.getInt("dormBuildId"));
			lookerList.add(looker);
		}
		return lookerList;
	}
	
	public List<Looker> lookerListWithBuild(Connection con, Looker l_looker, String buildName)throws Exception {
		List<Looker> lookerList = new ArrayList<Looker>();
		StringBuffer sb = new StringBuffer("select * from t_looker t1");
		sb.append(" and t1.buildName="+buildName);
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Looker looker=new Looker();
			looker.setLookerId(rs.getInt("lookerId"));
			looker.setStudentNum(rs.getString("studentNum"));
			looker.setDate(rs.getString("date"));
			looker.setDetail(rs.getString("detail"));
			looker.setBuildName(rs.getString("buildName"));
		//	looker.setDormBuildId(rs.getInt("dormBuildId"));
			lookerList.add(looker);
		}
		return lookerList;
	}
	
	public List<Looker> lookerListWithNumber(Connection con, Looker l_looker, String studentNum)throws Exception {
		List<Looker> lookerList = new ArrayList<Looker>();
		StringBuffer sb = new StringBuffer("select * from t_looker t1");
		/*if(StringUtil.isNotEmpty(workerNum)) {
			sb.append(" and t1.workerNum ="+workerNum);
		} */
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Looker looker=new Looker();
			looker.setLookerId(rs.getInt("lookerId"));
			looker.setStudentNum(rs.getString("studentNum"));
			looker.setDate(rs.getString("date"));
			looker.setDetail(rs.getString("detail"));
			looker.setBuildName(rs.getString("buildName"));
			//looker.setDormBuildId(rs.getInt("dormBuildId"));
			lookerList.add(looker);
		}
		return lookerList;
	}	
	
	public List<Looker> lookerListwithNum(Connection con, Looker l_looker, String studentNum)throws Exception {
		List<Looker> lookerList = new ArrayList<Looker>();
		StringBuffer sb = new StringBuffer("select * from t_looker t1");
		/*if(StringUtil.isNotEmpty(studentNum)) {
			sb.append(" and t1.workerNum ="+studentNum);
		} */
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Looker looker=new Looker();
			looker.setLookerId(rs.getInt("lookerId"));
			looker.setStudentNum(rs.getString("studentNum"));
			looker.setDate(rs.getString("date"));
			looker.setDetail(rs.getString("detail"));
			looker.setBuildName(rs.getString("buildName"));
			//looker.setDormBuildId(rs.getInt("dormBuildId"));
			lookerList.add(looker);
		}
		return lookerList;
	}	
/*	public List<DormBuild> dormBuildList(Connection con)throws Exception {
		List<DormBuild> dormBuildList = new ArrayList<DormBuild>();
		String sql = "select * from t_dormBuild";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			DormBuild dormBuild=new DormBuild();
			dormBuild.setDormBuildId(rs.getInt("dormBuildId"));
			dormBuild.setDetail(rs.getString("dormBuildDetail"));
			dormBuildList.add(dormBuild);
		}
		return dormBuildList;
	}*/

	/*public int lookerCount(Connection con, Looker l_looker)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from l_looker t1");
		if(StringUtil.isNotEmpty(l_looker.getBuildName())) {
			sb.append(" and t1.buildName like '%"+l_looker.getBuildName()+"%'");
		} else if(StringUtil.isNotEmpty(c_clean.getWorkerNum())) {
			sb.append(" and t1.studentNum like '%"+c_clean.getWorkerNum()+"%'");
		} 
		if(c_clean.getCleanId()!=0) {
			sb.append(" and t1.cleanId="+c_clean.getCleanId());
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
	if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}*/
	
	public Looker lookerShow(Connection con, String lookerId)throws Exception {
		String sql = "select * from t_looker t1 where t1.lookerId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, lookerId);
		ResultSet rs=pstmt.executeQuery();
		Looker looker = new Looker();
		while(rs.next()) {
			//Looker looker=new Looker();
			looker.setLookerId(rs.getInt("lookerId"));
			looker.setStudentNum(rs.getString("studentNum"));
			looker.setDate(rs.getString("date"));
			looker.setDetail(rs.getString("detail"));
			looker.setBuildName(rs.getString("buildName"));
			//looker.setDormBuildId(rs.getInt("dormBuildId"));
		}
		return looker;
	}
	
	public int lookerAdd(Connection con, Looker looker)throws Exception {
		String sql = "insert into t_looker values(null,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, looker.getStudentNum());
		pstmt.setString(4, looker.getDate());
		pstmt.setString(3, looker.getDetail());
		pstmt.setString(2, looker.getBuildName());
		//pstmt.setInt(5,looker.getDormBuildId());
		return pstmt.executeUpdate();
	}
	
	public int lookerDelete(Connection con, String lookerId)throws Exception {
		String sql = "delete from t_looker where lookerId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, lookerId);
		return pstmt.executeUpdate();
	}
	
	public int lookerUpdate(Connection con, Looker looker)throws Exception {
		String sql = "update t_looker set studentNum=?,date=?,detail=?,buildName=? where lookerId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, looker.getStudentNum());
		pstmt.setString(4, looker.getDate());
		pstmt.setString(3, looker.getDetail());
		pstmt.setString(2, looker.getBuildName());
		//pstmt.setInt(5,looker.getDormBuildId());
		pstmt.setInt(5, looker.getLookerId());
		return pstmt.executeUpdate();
	}
	
	
}
