package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lero.util.StringUtil;
import com.lero.model.Teacher;
//dao�� д�������ݿ�����
public class TeacherDao {	
	public List<Teacher> teacherList(Connection con, Teacher t_teacher)throws Exception {
		List<Teacher> teacherList = new ArrayList<Teacher>();
		StringBuffer sb = new StringBuffer("select * from t_teacher t1");
		if(StringUtil.isNotEmpty(t_teacher.getName())) {
			sb.append(" and t1.name like '%"+t_teacher.getName()+"%'");
		} else if(StringUtil.isNotEmpty(t_teacher.getTeacherNum())) {
			sb.append(" and t1.teacherNum like '%"+t_teacher.getTeacherNum()+"%'");
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Teacher teacher=new Teacher();
			teacher.setTeacherId(rs.getInt("teacherId"));
			teacher.setTeacherNum(rs.getString("teacherNum"));
			teacher.setName(rs.getString("name"));
			teacher.setPassword(rs.getString("password"));
			teacherList.add(teacher);
		}
		return teacherList;
	}
	
	public static Teacher getNameById(Connection con, String teacherNum)throws Exception {
		String sql = "select * from t_teacher t1 where t1.teacherNum=? and t1.teacherId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, teacherNum);
		ResultSet rs=pstmt.executeQuery();
		Teacher teacher = new Teacher();
		if(rs.next()) {
			teacher.setName(rs.getString("name"));
		}
		return teacher;
	}
	
	public boolean haveNameByNumber(Connection con, String teacherNum)throws Exception {
		String sql = "select * from t_teacher t1 where t1.teacherNum=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, teacherNum);
		ResultSet rs=pstmt.executeQuery();
		Teacher teacher = new Teacher();
		if(rs.next()) {
			teacher.setName(rs.getString("name"));
			return true;
		}
		return false;
	}	
	public int teacherCount(Connection con, Teacher t_teacher)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from t_teacher t1");
		if(StringUtil.isNotEmpty(t_teacher.getName())) {
			sb.append(" and t1.name like '%"+t_teacher.getName()+"%'");
		} else if(StringUtil.isNotEmpty(t_teacher.getTeacherNum())) {
			sb.append(" and t1.teacherNum like '%"+t_teacher.getTeacherNum()+"%'");
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}
	
	public Teacher teacherShow(Connection con, String teacherId)throws Exception {
		String sql = "select * from t_teacher t1 where t1.teacherId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, teacherId);
		ResultSet rs=pstmt.executeQuery();
		Teacher teacher = new Teacher();
		if(rs.next()) {
			teacher.setTeacherId(rs.getInt("teacherId"));
			teacher.setTeacherNum(rs.getString("teacherNum"));
			teacher.setName(rs.getString("name"));
			teacher.setPassword(rs.getString("password"));
		}
		return teacher;
	}
	
	public int teacherAdd(Connection con, Teacher teacher)throws Exception {
		String sql = "insert into t_teacher values(null,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, teacher.getTeacherNum());
		pstmt.setString(2, teacher.getPassword());
		pstmt.setString(3, teacher.getName());
		return pstmt.executeUpdate();
	}
	
	public int teacherDelete(Connection con, String teacherId)throws Exception {
		String sql = "delete from t_teacher where teacherId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, teacherId);
		return pstmt.executeUpdate();
	}
	
	public int teacherUpdate(Connection con, Teacher teacher)throws Exception {
		String sql = "update t_teacher set teacherNum=?,password=?,name=? where teacherId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, teacher.getTeacherNum());
		pstmt.setString(2, teacher.getPassword());
		pstmt.setString(3, teacher.getName());
		pstmt.setInt(4, teacher.getTeacherId());
		return pstmt.executeUpdate();
	}
	
	
}
