package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lero.model.Record;
import com.lero.util.StringUtil;

public class RecordDao {
	public List<Record> recordList(Connection con, Record r_record)throws Exception {
		List<Record> recordList = new ArrayList<Record>();
		StringBuffer sb = new StringBuffer("select * from t_record t1");
		if(StringUtil.isNotEmpty(r_record.getStudentNumber())) {
			sb.append(" and t1.studentNumber like '%"+r_record.getStudentNumber()+"%'");
		} else if(StringUtil.isNotEmpty(r_record.getStudentName())) {
			sb.append(" and t1.studentName like '%"+r_record.getStudentName()+"%'");
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Record record=new Record();
			record.setRecordId(rs.getInt("recordId"));
			record.setStudentNumber(rs.getString("studentNumber"));
			record.setStudentName(rs.getString("studentName"));
			record.setDormBuildId(rs.getInt("dormBuildId"));
			record.setDate(rs.getString("date"));
			record.setDetail(rs.getString("detail"));
			record.setDormName(rs.getString("dormName"));
			recordList.add(record);
		}
		return recordList;
	}
	
	public List<Record> recordListWithBuild(Connection con, Record r_record, int buildId)throws Exception {
		List<Record> recordList = new ArrayList<Record>();
		StringBuffer sb = new StringBuffer("select * from t_record t1");
		/*if(StringUtil.isNotEmpty(r_record.getStudentNumber())) {
			sb.append(" and t1.studentNumber like '%"+r_record.getStudentNumber()+"%'");
		} else if(StringUtil.isNotEmpty(r_record.getStudentName())) {
			sb.append(" and t1.studentName like '%"+r_record.getStudentName()+"%'");
		}
		sb.append(" and t1.dormBuildId="+buildId);*/
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Record record=new Record();
			record.setRecordId(rs.getInt("recordId"));
			record.setStudentNumber(rs.getString("studentNumber"));
			record.setStudentName(rs.getString("studentName"));
			record.setDormBuildId(rs.getInt("dormBuildId"));
			record.setDate(rs.getString("date"));
			record.setDetail(rs.getString("detail"));
			record.setDormName(rs.getString("dormName"));
			recordList.add(record);
		}
		return recordList;
	}
	
	public List<Record> recordListWithNumber(Connection con, Record r_record, String studentNumber)throws Exception {
		List<Record> recordList = new ArrayList<Record>();
		StringBuffer sb = new StringBuffer("select * from t_record t1");
		if(StringUtil.isNotEmpty(studentNumber)) {
			sb.append(" and t1.studentNumber ="+studentNumber);
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Record record=new Record();
			record.setRecordId(rs.getInt("recordId"));
			record.setStudentNumber(rs.getString("studentNumber"));
			record.setStudentName(rs.getString("studentName"));
			record.setDormBuildId(rs.getInt("dormBuildId"));
			record.setDormName(rs.getString("dormName"));
			record.setDate(rs.getString("date"));
			record.setDetail(rs.getString("detail"));
			recordList.add(record);
		}
		return recordList;
	}	
/*	public List<DormBuild> dormBuildList(Connection con)throws Exception {
		List<DormBuild> dormBuildList = new ArrayList<DormBuild>();
		String sql = "select * from t_dormBuild";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			DormBuild dormBuild=new DormBuild();
			dormBuild.setDormBuildId(rs.getInt("dormBuildId"));
			dormBuild.setDetail(rs.getString("dormBuildDetail"));
			dormBuildList.add(dormBuild);
		}
		return dormBuildList;
	}*/
/*
	public int recordCount(Connection con, Record r_record)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from t_record t1");
		if(StringUtil.isNotEmpty(r_record.getStudentName())) {
			sb.append(" and t1.name like '%"+r_record.getStudentName()+"%'");
		} else if(StringUtil.isNotEmpty(r_record.getStudentNumber())) {
			sb.append(" and t1.studentNumber like '%"+r_record.getStudentNumber()+"%'");
		} 
		if(r_record.getDormBuildId()!=0) {
			sb.append(" and t1.dormBuildId="+r_record.getDormBuildId());
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
	if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}*/
	
	public Record recordShow(Connection con, String recordId)throws Exception {
		String sql = "select * from t_record t1 where t1.recordId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, recordId);
		ResultSet rs=pstmt.executeQuery();
		Record record = new Record();
		while(rs.next()) {
			record.setRecordId(rs.getInt("recordId"));
			record.setStudentNumber(rs.getString("studentNumber"));
			record.setStudentName(rs.getString("studentName"));
			record.setDormBuildId(rs.getInt("dormBuildId"));
			record.setDate(rs.getString("date"));
			record.setDetail(rs.getString("detail"));
			record.setDormName(rs.getString("dormName"));
		}
		return record;
	}
	
	public int recordAdd(Connection con, Record record)throws Exception {
		String sql = "insert into t_record values(null,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, record.getStudentNumber());
		pstmt.setString(2, record.getStudentName());
		pstmt.setInt(3, record.getDormBuildId());
		pstmt.setString(4, record.getDate());
		pstmt.setString(5, record.getDetail());
		pstmt.setString(6, record.getDormName());
		return pstmt.executeUpdate();
	}
	
	public int recordDelete(Connection con, String recordId)throws Exception {
		String sql = "delete from t_record where recordId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, recordId);
		return pstmt.executeUpdate();
	}
	
	public int recordUpdate(Connection con, Record record)throws Exception {
		String sql = "update t_record set studentNumber=?,studentName=?,dormBuildId=?,detail=?,dormName=? where recordId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, record.getStudentNumber());
		pstmt.setString(2, record.getStudentName());
		pstmt.setInt(3, record.getDormBuildId());
		pstmt.setString(4, record.getDetail());
		pstmt.setString(5, record.getDormName());
		pstmt.setInt(6, record.getRecordId());
		return pstmt.executeUpdate();
	}
	
	
}
