package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lero.model.Maintain;
import com.lero.util.StringUtil;

public class MaintainDao {
	public List<Maintain> maintainList(Connection con, Maintain m_maintain)throws Exception {
		List<Maintain> maintainList = new ArrayList<Maintain>();
		StringBuffer sb = new StringBuffer("select * from t_maintain t1");
		/*if(StringUtil.isNotEmpty(m_maintain.get())) {
			sb.append(" and t1.buildName like '%"+c_clean.getBuildName()+"%'");
		} else if(StringUtil.isNotEmpty(c_clean.getWorkerNum())) {
			sb.append(" and t1.studentName like '%"+c_clean.getWorkerNum()+"%'");
		}*/
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Maintain maintain=new Maintain();
			maintain.setMaintainId(rs.getInt("maintainId"));
			maintain.setWorkerNum(rs.getString("workerNum"));
			maintain.setBuildName(rs.getString("buildName"));
			maintain.setDetail(rs.getString("detail"));
			maintain.setDate(rs.getString("date"));
			maintainList.add(maintain);
		}
		return maintainList;
	}
	
	public List<Maintain> maintainListWithBuild(Connection con, Maintain m_maintain, String buildName)throws Exception {
		List<Maintain> maintainList = new ArrayList<Maintain>();
		StringBuffer sb = new StringBuffer("select * from t_maintain t1");
		/*if(StringUtil.isNotEmpty(c_clean.getBuildName())) {
			sb.append(" and t1.buildName like '%"+c_clean.getBuildName()+"%'");
		} *//*else if(StringUtil.isNotEmpty(r_record.getStudentName())) {
			sb.append(" and t1.studentName like '%"+r_record.getStudentName()+"%'");
		}*/
		/*sb.append(" and t1.buildName="+buildName);*/
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Maintain maintain=new Maintain();
			maintain.setMaintainId(rs.getInt("maintainId"));
			maintain.setWorkerNum(rs.getString("workerNum"));
			maintain.setBuildName(rs.getString("buildName"));
			maintain.setDetail(rs.getString("detail"));
			maintain.setDate(rs.getString("date"));
			maintainList.add(maintain);
		}
		return maintainList;
	}
	
	public List<Maintain> maintainListWithNumber(Connection con, Maintain m_maintain, String workerNum)throws Exception {
		List<Maintain> maintainList = new ArrayList<Maintain>();
		StringBuffer sb = new StringBuffer("select * from t_maintain t1");
	/*	if(StringUtil.isNotEmpty(workerNum)) {
			sb.append(" and t1.workerNum ="+workerNum);
		} */
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Maintain maintain=new Maintain();
			maintain.setMaintainId(rs.getInt("maintainId"));
			maintain.setWorkerNum(rs.getString("workerNum"));
			maintain.setBuildName(rs.getString("buildName"));
			maintain.setDetail(rs.getString("detail"));
			maintain.setDate(rs.getString("date"));
			maintainList.add(maintain);
		}
		return maintainList;
	}	
	
	public List<Maintain> maintainListWithName(Connection con, Maintain m_maintain, String buildName)throws Exception {
		List<Maintain> maintainList = new ArrayList<Maintain>();
		StringBuffer sb = new StringBuffer("select * from t_maintain t1");
		if(StringUtil.isNotEmpty(buildName)) {
			sb.append(" and t1.buildName ="+buildName);
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Maintain maintain=new Maintain();
			maintain.setMaintainId(rs.getInt("maintainId"));
			maintain.setWorkerNum(rs.getString("workerNum"));
			maintain.setBuildName(rs.getString("buildName"));
			maintain.setDetail(rs.getString("detail"));
			maintain.setDate(rs.getString("date"));
			maintainList.add(maintain);
		}
		return maintainList;
	}	
/*	public List<DormBuild> dormBuildList(Connection con)throws Exception {
		List<DormBuild> dormBuildList = new ArrayList<DormBuild>();
		String sql = "select * from t_dormBuild";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			DormBuild dormBuild=new DormBuild();
			dormBuild.setDormBuildId(rs.getInt("dormBuildId"));
			dormBuild.setDetail(rs.getString("dormBuildDetail"));
			dormBuildList.add(dormBuild);
		}
		return dormBuildList;
	}*/

	public int maintainCount(Connection con, Maintain m_maintain)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from t_maintain t1");
		if(StringUtil.isNotEmpty(m_maintain.getBuildName())) {
			sb.append(" and t1.buildName like '%"+m_maintain.getBuildName()+"%'");
		} else if(StringUtil.isNotEmpty(m_maintain.getWorkerNum())) {
			sb.append(" and t1.workerNum like '%"+m_maintain.getWorkerNum()+"%'");
		} 
		if(m_maintain.getMaintainId()!=0) {
			sb.append(" and t1.maintainId="+m_maintain.getMaintainId());
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
	if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}
	
	public Maintain maintainShow(Connection con, String maintainId)throws Exception {
		String sql = "select * from t_maintain t1 where t1.maintainId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, maintainId);
		ResultSet rs=pstmt.executeQuery();
		Maintain maintain = new Maintain();
		while(rs.next()) {
			maintain.setMaintainId(rs.getInt("maintainId"));
			maintain.setWorkerNum(rs.getString("workerNum"));
			maintain.setBuildName(rs.getString("buildName"));
			maintain.setDetail(rs.getString("detail"));
			maintain.setDate(rs.getString("date"));
		}
		return maintain;
	}
	
	public int maintainAdd(Connection con, Maintain maintain)throws Exception {
		String sql = "insert into t_maintain values(null,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		
		pstmt.setString(1, maintain.getBuildName());
		pstmt.setString(2, maintain.getWorkerNum());
		pstmt.setString(3, maintain.getDetail());
		pstmt.setString(4, maintain.getDate());
		return pstmt.executeUpdate();
	}
	
	public int maintainDelete(Connection con, String maintainId)throws Exception {
		String sql = "delete from t_maintain where maintainId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, maintainId);
		return pstmt.executeUpdate();
	}
	
	public int maintainUpdate(Connection con, Maintain maintain)throws Exception {
		String sql = "update t_maintain set workerNum=?,buildName=?,detail=?,date=? where maintainId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, maintain.getWorkerNum());
		pstmt.setString(2, maintain.getBuildName());
		pstmt.setString(3, maintain.getDetail());
		pstmt.setString(4, maintain.getDate());
		pstmt.setInt(5, maintain.getMaintainId());
		return pstmt.executeUpdate();
	}
	
	
}
