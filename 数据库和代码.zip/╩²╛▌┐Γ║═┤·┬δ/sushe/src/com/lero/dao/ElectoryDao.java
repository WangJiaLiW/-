package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lero.model.Electory;
import com.lero.util.StringUtil;

public class ElectoryDao {
	public List<Electory> electoryList(Connection con, Electory e_electory)throws Exception {
		List<Electory> electoryList = new ArrayList<Electory>();
		StringBuffer sb = new StringBuffer("select * from t_electory t1");
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Electory electory=new Electory();
			electory.setElectoryId(rs.getInt("electoryId"));
			electory.setDormNum(rs.getString("dormNum"));
			electory.setName(rs.getString("name"));
			electory.setDetail(rs.getString("detail"));
			electoryList.add(electory);
		}
		return electoryList;
	}
	
	public List<Electory> electoryListWithNumber(Connection con, Electory e_electory, String dormNum)throws Exception {
		List<Electory> electoryList = new ArrayList<Electory>();
		StringBuffer sb = new StringBuffer("select * from t_electory t1 where 1=1");
		if(StringUtil.isNotEmpty(dormNum)) {
			sb.append(" and t1.dormNum='"+dormNum+"'");
		} 
		System.out.println(sb.toString());
		PreparedStatement pstmt = con.prepareStatement(sb.toString());
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Electory electory=new Electory();
			electory.setElectoryId(rs.getInt("electoryId"));
			electory.setDormNum(rs.getString("dormNum"));
			electory.setName(rs.getString("name"));
			electory.setDetail(rs.getString("detail"));
			electoryList.add(electory);
		}
		return electoryList;
	}	
	public List<Electory> electoryListWithName(Connection con, Electory e_electory, String name)throws Exception {
		List<Electory> electoryList = new ArrayList<Electory>();
		StringBuffer sb = new StringBuffer("select * from t_electory t1 where 1=1");
		if(StringUtil.isNotEmpty(name)) {
			sb.append(" and t1.name='"+name+"'");
		} 
		System.out.println(sb.toString());
		PreparedStatement pstmt = con.prepareStatement(sb.toString());
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Electory electory=new Electory();
			electory.setElectoryId(rs.getInt("electoryId"));
			electory.setDormNum(rs.getString("dormNum"));
			electory.setName(rs.getString("name"));
			electory.setDetail(rs.getString("detail"));
			electoryList.add(electory);
		}
		return electoryList;
	}	
	
	public Electory electoryShow(Connection con, String electoryId)throws Exception {
		String sql = "select * from t_electory t1 where t1.electoryId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, electoryId);
		ResultSet rs=pstmt.executeQuery();
		Electory electory = new Electory();
		while(rs.next()) {
			electory.setElectoryId(rs.getInt("electoryId"));
			electory.setDormNum(rs.getString("dormNum"));
			electory.setName(rs.getString("name"));
			electory.setDetail(rs.getString("detail"));
		}
		return electory;
	}
	
	public int electoryAdd(Connection con, Electory electory)throws Exception {
		String sql = "insert into t_electory values(null,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, electory.getDormNum());
		pstmt.setString(2, electory.getName());
		pstmt.setString(3, electory.getDetail());
		return pstmt.executeUpdate();
	}
	
	public int electoryDelete(Connection con, String electoryId)throws Exception {
		String sql = "delete from t_electory where electoryId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, electoryId);
		return pstmt.executeUpdate();
	}
	
	public int electoryUpdate(Connection con, Electory electory)throws Exception {
		String sql = "update t_electory set dormNum=?,name=?,detail=? where electoryId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, electory.getDormNum());
		pstmt.setString(2, electory.getName());
		pstmt.setString(3, electory.getDetail());
		pstmt.setInt(4, electory.getElectoryId());
		return pstmt.executeUpdate();
	}
	
	
}
