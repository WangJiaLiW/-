package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lero.util.StringUtil;
import com.lero.model.Worker;
//dao�� д�������ݿ�����
public class WorkerDao {	
	public List<Worker> workerList(Connection con, Worker w_worker)throws Exception {
		List<Worker> workerList = new ArrayList<Worker>();
		StringBuffer sb = new StringBuffer("select * from t_worker t1");
		if(StringUtil.isNotEmpty(w_worker.getName())) {
			sb.append(" and t1.name like '%"+w_worker.getName()+"%'");
		} else if(StringUtil.isNotEmpty(w_worker.getWorkerNum())) {
			sb.append(" and t1.workerNum like '%"+w_worker.getWorkerNum()+"%'");
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Worker worker=new Worker();
			worker.setWorkerId(rs.getInt("workerId"));
			worker.setWorkerNum(rs.getString("workerNum"));
			worker.setName(rs.getString("name"));
			worker.setSex(rs.getString("sex"));
			worker.setTel(rs.getInt("tel"));
			worker.setPassword(rs.getString("password"));
			workerList.add(worker);
		}
		return workerList;
	}
	
	public static Worker getNameById(Connection con, String workerNum)throws Exception {
		String sql = "select * from t_worker t1 where t1.workerNum=? and t1.workerId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, workerNum);
		ResultSet rs=pstmt.executeQuery();
		Worker worker = new Worker();
		if(rs.next()) {
			worker.setName(rs.getString("name"));
		}
		return worker;
	}
	
	public boolean haveNameByNumber(Connection con, String workerNum)throws Exception {
		String sql = "select * from t_worker t1 where t1.workerNum=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, workerNum);
		ResultSet rs=pstmt.executeQuery();
		Worker worker = new Worker();
		if(rs.next()) {
			worker.setName(rs.getString("name"));
			return true;
		}
		return false;
	}	
	public int workerCount(Connection con, Worker w_worker)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from t_worker t1");
		if(StringUtil.isNotEmpty(w_worker.getName())) {
			sb.append(" and t1.name like '%"+w_worker.getName()+"%'");
		} else if(StringUtil.isNotEmpty(w_worker.getWorkerNum())) {
			sb.append(" and t1.workerNum like '%"+w_worker.getWorkerNum()+"%'");
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}
	
	public Worker workerShow(Connection con, String workerId)throws Exception {
		String sql = "select * from t_worker t1 where t1.workerId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, workerId);
		ResultSet rs=pstmt.executeQuery();
		Worker worker = new Worker();
		if(rs.next()) {
			worker.setWorkerId(rs.getInt("workerId"));
			worker.setWorkerNum(rs.getString("workerNum"));
			worker.setName(rs.getString("name"));
			worker.setSex(rs.getString("sex"));
			worker.setTel(rs.getInt("tel"));
			worker.setPassword(rs.getString("password"));
		}
		return worker;
	}
	
	public int workerAdd(Connection con, Worker worker)throws Exception {
		String sql = "insert into t_worker values(null,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, worker.getWorkerNum());
		pstmt.setString(2, worker.getPassword());
		pstmt.setString(3, worker.getName());
		pstmt.setString(4, worker.getSex());
		pstmt.setInt(5, worker.getTel());
		return pstmt.executeUpdate();
	}
	
	public int workerDelete(Connection con, String workerId)throws Exception {
		String sql = "delete from t_worker where workerId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, workerId);
		return pstmt.executeUpdate();
	}
	
	public int workerUpdate(Connection con, Worker worker)throws Exception {
		String sql = "update t_worker set workerNum=?,password=?,name=?,sex=?,tel=? where workerId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, worker.getWorkerNum());
		pstmt.setString(2, worker.getPassword());
		pstmt.setString(3, worker.getName());
		pstmt.setString(4, worker.getSex());
		pstmt.setInt(5, worker.getTel());
		pstmt.setInt(6, worker.getWorkerId());
		return pstmt.executeUpdate();
	}
	
	
}
