package com.lero.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.lero.model.Dorm;
import com.lero.model.PageBean;
import com.lero.util.StringUtil;

public class DormDao {
	public List<Dorm> dormList(Connection con, PageBean pageBean, Dorm d_dorm)throws Exception {
		List<Dorm> dormList = new ArrayList<Dorm>();
		StringBuffer sb = new StringBuffer("SELECT * from t_dorm t1 ");
		if(StringUtil.isNotEmpty(d_dorm.getGrade())) {
			sb.append(" where t1.grade like '%"+d_dorm.getGrade()+"%'");
		} else if(StringUtil.isNotEmpty(d_dorm.getDormNum())) {
			sb.append(" where t1.dormNum like '%"+d_dorm.getDormNum()+"%'");
		}
		if(pageBean != null) {
			sb.append(" limit "+pageBean.getStart()+","+pageBean.getPageSize());
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString());
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Dorm dorm=new Dorm();
			dorm.setDormId(rs.getInt("dormId"));
			dorm.setDormNum(rs.getString("dormNum"));
			dorm.setName(rs.getString("name"));
			dorm.setGrade(rs.getString("grade"));
			dorm.setDate(rs.getString("date"));
			dorm.setDetail(rs.getString("detail"));
			dormList.add(dorm);
		}
		return dormList;
	}
	
	
	public int dormCount(Connection con, Dorm d_dorm)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from t_dorm t1");
		if(StringUtil.isNotEmpty(d_dorm.getGrade())) {
			sb.append(" where t1.grade like '%"+d_dorm.getGrade()+"%'");
		} else if(StringUtil.isNotEmpty(d_dorm.getDormNum())) {
			sb.append(" where t1.dormNum like '%"+d_dorm.getDormNum()+"%'");
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString());
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}
	
	
/*	public List<Dorm> dormListWithGrade(Connection con, Dorm d_dorm, String grade)throws Exception {
		List<Dorm> dormList = new ArrayList<Dorm>();
		StringBuffer sb = new StringBuffer("select * from t_dorm t1");
		if(StringUtil.isNotEmpty(d_dorm.getGrade())) {
			sb.append(" and t1.grade like'%"+d_dorm.getGrade()+"%'");
		} else if(StringUtil.isNotEmpty(d_dorm.getDormNum())) {
			sb.append(" and t1.dormNum like '%"+d_dorm.getDormNum()+"%'");
		}
		//sb.append(" and t1.dormId="+dormId);
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Dorm dorm=new Dorm();
			dorm.setDormId(rs.getInt("dormId"));
			dorm.setDormNum(rs.getString("dormNum"));
			dorm.setName(rs.getString("name"));
			dorm.setGrade(rs.getString("grade"));
			dorm.setDate(rs.getString("date"));
			dorm.setDetail(rs.getString("detail"));
	//		dorm.setElectory(rs.getString("electory"));
			dormList.add(dorm);
		}
		return dormList;
	}
	
	public List<Dorm> dormListWithNumber(Connection con, Dorm d_dorm, String dormNum)throws Exception {
		List<Dorm> dormList = new ArrayList<Dorm>();
		StringBuffer sb = new StringBuffer("select * from t_dorm t1");
		if(StringUtil.isNotEmpty(dormNum)) {
			sb.append(" and t1.dormNum ="+dormNum);
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Dorm dorm=new Dorm();
			dorm.setDormId(rs.getInt("dormId"));
			dorm.setDormNum(rs.getString("dormNum"));
			dorm.setName(rs.getString("name"));
			dorm.setGrade(rs.getString("grade"));
			dorm.setDate(rs.getString("date"));
			dorm.setDetail(rs.getString("detail"));
	//		dorm.setElectory(rs.getString("electory"));
			dormList.add(dorm);
		}
		return dormList;
	}	
	*/
	public Dorm dormShow(Connection con, String dormId)throws Exception {
		String sql = "select * from t_dorm t1 where t1.dormId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, dormId);
		ResultSet rs=pstmt.executeQuery();
		Dorm dorm = new Dorm();
		while(rs.next()) {
			dorm.setDormId(rs.getInt("dormId"));
			dorm.setDormNum(rs.getString("dormNum"));
			dorm.setName(rs.getString("name"));
			dorm.setGrade(rs.getString("grade"));
			dorm.setDate(rs.getString("date"));
			dorm.setDetail(rs.getString("detail"));
//			dorm.setElectory(rs.getString("electory"));
		}
		return dorm;
	}
	
	public int dormAdd(Connection con, Dorm dorm)throws Exception {
		String sql = "insert into t_dorm values(null,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, dorm.getDormNum());
		pstmt.setString(2, dorm.getName());
		pstmt.setString(3, dorm.getGrade());
		pstmt.setString(4, dorm.getDate());
//		pstmt.setString(5, dorm.getElectory());
		pstmt.setString(5, dorm.getDetail());
		return pstmt.executeUpdate();
	}
	
	public int dormDelete(Connection con, String dormId)throws Exception {
		String sql = "delete from t_dorm where dormId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, dormId);
		return pstmt.executeUpdate();
	}
	
	public int dormUpdate(Connection con, Dorm dorm)throws Exception {
		String sql = "update t_dorm set dormNum=?,name=?,grade=?,date=?,detail=? where dormId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, dorm.getDormNum());
		pstmt.setString(2, dorm.getName());
		pstmt.setString(3, dorm.getGrade());
		pstmt.setString(4, dorm.getDate());
	//	pstmt.setString(5, dorm.getElectory());
		pstmt.setString(5, dorm.getDetail());
		pstmt.setInt(6, dorm.getDormId());
		return pstmt.executeUpdate();
	}
	public boolean havedormNumByGrade(Connection con, String grade) throws Exception {
		String sql = "select * from t_dorm t1 where t1.grade=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, grade);
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			return true;
		}
		return false;
	}
	
}
