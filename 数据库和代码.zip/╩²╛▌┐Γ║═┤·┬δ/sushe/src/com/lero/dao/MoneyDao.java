package com.lero.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.lero.model.Money;
import com.lero.util.StringUtil;

public class MoneyDao {
	public List<Money> moneyList(Connection con, Money m_money)throws Exception {
		List<Money> moneyList = new ArrayList<Money>();
		StringBuffer sb = new StringBuffer("select * from t_money t1");
		if(StringUtil.isNotEmpty(m_money.getName())) {
			sb.append(" and t1.name like '%"+m_money.getName()+"%'");
		} else if(StringUtil.isNotEmpty(m_money.getStudentNum())) {
			sb.append(" and t1.studentNum like '%"+m_money.getStudentNum()+"%'");
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Money money=new Money();
			money.setMoneyId(rs.getInt("moneyId"));
			money.setName(rs.getString("name"));
			money.setAmount(rs.getString("amount"));
			money.setStudentNum(rs.getString("studentNum"));
			money.setWorkerNum(rs.getString("workerNum"));
		}
		return moneyList;
	}
	
	public List<Money> moneyListWithName(Connection con, Money m_money, String name)throws Exception {
		List<Money> moneyList = new ArrayList<Money>();
		StringBuffer sb = new StringBuffer("select * from t_money t1");
		if(StringUtil.isNotEmpty(m_money.getName())) {
			sb.append(" and t1.name like '%"+m_money.getName()+"%'");
		} else if(StringUtil.isNotEmpty(m_money.getStudentNum())) {
			sb.append(" and t1.studentNum like '%"+m_money.getStudentNum()+"%'");
		}
		sb.append(" and t1.name="+name);
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Money money=new Money();
			money.setMoneyId(rs.getInt("moneyId"));
			money.setName(rs.getString("name"));
			money.setAmount(rs.getString("amount"));
			money.setStudentNum(rs.getString("studentNum"));
			money.setWorkerNum(rs.getString("workerNum"));
			moneyList.add(money);
		}
		return moneyList;
	}
	
	public List<Money> moneyListWithNumber(Connection con, Money m_money, String studentNum)throws Exception {
		List<Money> moneyList = new ArrayList<Money>();
		StringBuffer sb = new StringBuffer("select * from t_money t1");
		if(StringUtil.isNotEmpty(studentNum)) {
			sb.append(" and t1.studentNum ="+studentNum);
		} 
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Money money=new Money();
			money.setMoneyId(rs.getInt("moneyId"));
			money.setName(rs.getString("name"));
			money.setStudentNum(rs.getString("studentNum"));
			money.setAmount(rs.getString("amount"));
			money.setWorkerNum(rs.getString("workerNum"));
			moneyList.add(money);
		}
		return moneyList;
	}	
	
	public List<Money> moneyListWithNum(Connection con, Money m_money, String workerNum)throws Exception {
		List<Money> moneyList = new ArrayList<Money>();
		StringBuffer sb = new StringBuffer("select * from t_money t1");
		/*if(StringUtil.isNotEmpty(workerNum)) {
			sb.append(" and t1.studentNum ="+workerNum);
		} */
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Money money=new Money();
			money.setMoneyId(rs.getInt("moneyId"));
			money.setName(rs.getString("name"));
			money.setStudentNum(rs.getString("studentNum"));
			money.setAmount(rs.getString("amount"));
			money.setWorkerNum(rs.getString("workerNum"));
			moneyList.add(money);
		}
		return moneyList;
	}	
	
	
	public List<Money> MoneyListWithId(Connection con,Money moneyId)throws Exception {
		List<Money> moneyList = new ArrayList<Money>();
		String sql = "select * from t_money";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Money money=new Money();
			money.setMoneyId(rs.getInt("moneyId"));
			money.setName(rs.getString("name"));
			money.setStudentNum(rs.getString("studentNum"));
			money.setAmount(rs.getString("amount"));
			money.setWorkerNum(rs.getString("workerNum"));
			moneyList.add(moneyId);
		}
		return moneyList;
	}
	
	

	public int moneyCount(Connection con, Money m_money)throws Exception {
		StringBuffer sb = new StringBuffer("select count(*) as total from t_money t1");
		if(StringUtil.isNotEmpty(m_money.getName())) {
			sb.append(" and t1.name like '%"+m_money.getName()+"%'");
		} else if(StringUtil.isNotEmpty(m_money.getStudentNum())) {
			sb.append(" and t1.studentNum like '%"+m_money.getStudentNum()+"%'");
		}  
		if(m_money.getMoneyId()!=0) {
			sb.append(" and t1.moneyId="+m_money.getMoneyId());
		}
		PreparedStatement pstmt = con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		ResultSet rs = pstmt.executeQuery();
	if(rs.next()) {
			return rs.getInt("total");
		} else {
			return 0;
		}
	}
	
	public Money moneyShow(Connection con, String moneyId)throws Exception {
		String sql = "select * from t_money t1 where t1.moneyId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, moneyId);
		ResultSet rs=pstmt.executeQuery();
		Money money = new Money();
		while(rs.next()) {
			money.setMoneyId(rs.getInt("moneyId"));
			money.setName(rs.getString("name"));
			money.setAmount(rs.getString("amount"));
			money.setStudentNum(rs.getString("studentNum"));
			money.setWorkerNum(rs.getString("workerNum"));
		}
		return money;
	}
	
	public int moneyAdd(Connection con, Money money)throws Exception {
		String sql = "insert into t_money values(null,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, money.getName());
		pstmt.setString(2, money.getAmount());
		pstmt.setString(3,money.getStudentNum());
		pstmt.setString(4,money.getWorkerNum());
		return pstmt.executeUpdate();
	}
	
	public int moneyDelete(Connection con, String moneyId)throws Exception {
		String sql = "delete from t_money where moneyId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, moneyId);
		return pstmt.executeUpdate();
	}
	
	public int moneyUpdate(Connection con, Money money)throws Exception {
		String sql = "update t_money set name=?,amount=?,studentNum=?,workerNum=? where moneyId=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, money.getName());
		pstmt.setString(2, money.getAmount());
		pstmt.setString(3, money.getStudentNum());
		pstmt.setString(4, money.getWorkerNum());
		pstmt.setInt(5, money.getMoneyId());
		return pstmt.executeUpdate();
	}
	
	
}
