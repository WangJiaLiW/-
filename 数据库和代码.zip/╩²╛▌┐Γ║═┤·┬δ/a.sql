/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.0.22-community-nt : Database - db_dorm
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_dorm` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_dorm`;

/*Table structure for table `t_admin` */

DROP TABLE IF EXISTS `t_admin`;

CREATE TABLE `t_admin` (
  `adminId` int(11) NOT NULL auto_increment,
  `userName` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  `name` varchar(20) default NULL,
  `sex` varchar(10) default NULL,
  `tel` varchar(20) default NULL,
  PRIMARY KEY  (`adminId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_dorm` */

DROP TABLE IF EXISTS `t_dorm`;

CREATE TABLE `t_dorm` (
  `dormId` int(11) NOT NULL auto_increment,
  `dormBuildId` int(11) default NULL,
  `dormName` varchar(20) default NULL,
  `dormType` varchar(20) default NULL,
  `dormNumber` int(11) default NULL,
  `dormTel` varchar(20) default NULL,
  PRIMARY KEY  (`dormId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_dormbuild` */

DROP TABLE IF EXISTS `t_dormbuild`;

CREATE TABLE `t_dormbuild` (
  `dormBuildId` int(11) NOT NULL auto_increment,
  `dormBuildName` varchar(20) default NULL,
  `dormBuildDetail` varchar(50) default NULL,
  PRIMARY KEY  (`dormBuildId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_dormmanager` */

DROP TABLE IF EXISTS `t_dormmanager`;

CREATE TABLE `t_dormmanager` (
  `dormManId` int(11) NOT NULL auto_increment,
  `userName` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  `dormBuildId` int(11) default NULL,
  `name` varchar(20) default NULL,
  `sex` varchar(20) default NULL,
  `tel` varchar(20) default NULL,
  PRIMARY KEY  (`dormManId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_record` */

DROP TABLE IF EXISTS `t_record`;

CREATE TABLE `t_record` (
  `recordId` int(11) NOT NULL auto_increment,
  `studentNumber` varchar(20) default NULL,
  `studentName` varchar(30) default NULL,
  `dormBuildId` int(11) default NULL,
  `dormName` varchar(11) default NULL,
  `date` date default NULL,
  `detail` varchar(50) default NULL,
  PRIMARY KEY  (`recordId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `t_student` */

DROP TABLE IF EXISTS `t_student`;

CREATE TABLE `t_student` (
  `studentId` int(11) NOT NULL auto_increment,
  `stuNum` varchar(20) default NULL,
  `password` varchar(20) default NULL,
  `name` varchar(20) default NULL,
  `dormBuildId` int(11) default NULL,
  `dormName` varchar(11) default NULL,
  `sex` varchar(10) default NULL,
  `tel` varchar(15) default NULL,
  PRIMARY KEY  (`studentId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
